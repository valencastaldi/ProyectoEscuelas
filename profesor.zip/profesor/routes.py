from backend.examenDAO import ExamenDAO
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from backend.usuarioDAO import UsuarioDAO
from backend.plan_academico import PlanAcademicoDAO
from collections import defaultdict

profesor_bp = Blueprint('profesor', __name__, url_prefix='/profesor', template_folder='templates')

def validar_rol(roles):
    if 'usuario' not in session:
        return False
    if isinstance(roles, str):
        roles = [roles]
    return session['usuario']['rol'] in roles

def redireccion_no_autorizado():
    flash("No autorizado")
    return redirect(url_for('auth.login'))

@profesor_bp.route('/dashboard')
def dashboard():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    return render_template('profesor/dashboard.html')

# ----- NOTAS -----
@profesor_bp.route('/notas', methods=['GET', 'POST'])
def ver_notas():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    notas = None
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        profesor_dni = session['usuario']['dni']
        notas = UsuarioDAO.obtener_notas_por_profesor(profesor_dni, dni_alumno)
    return render_template("profesor/ver_notas_alumno.html", notas=notas)


@profesor_bp.route('/agregar-nota', methods=['GET', 'POST'])
def agregar_nota():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        materia_id = request.form['materia_id']
        nota = request.form['nota']
        resultado = UsuarioDAO.agregar_nota(session['usuario']['dni'], dni_alumno, nota, materia_id)
        flash(resultado.get('mensaje', 'Error'))
        return redirect(url_for('profesor.dashboard'))
    return render_template("profesor/agregar_nota.html")

@profesor_bp.route('/actualizar-nota', methods=['GET', 'POST'])
def actualizar_nota():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        materia_id = request.form['materia_id']
        nueva_nota = request.form['nueva_nota']
        resultado = UsuarioDAO.actualizar_nota(session['usuario']['dni'], dni_alumno, nueva_nota, materia_id)
        flash(resultado.get('mensaje', 'Error'))
        return redirect(url_for('profesor.dashboard'))
    return render_template("profesor/actualizar_nota.html")

# ----- ASISTENCIAS -----
@profesor_bp.route('/ver-asistencias', methods=['GET', 'POST'])
def ver_asistencias():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    asistencias = None
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        asistencias = UsuarioDAO.obtener_asistencias(dni_alumno)
    return render_template("profesor/ver_asistencias_alumno.html", asistencias=asistencias)

@profesor_bp.route('/registrar-asistencia', methods=['GET', 'POST'])
def registrar_asistencia():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        materia_id = request.form['materia_id']
        presente = request.form['presente'].lower() == 'true'
        resultado = UsuarioDAO.registrar_asistencia(session['usuario']['dni'], dni_alumno, presente, materia_id)
        flash(resultado.get('mensaje', 'Error'))
        return redirect(url_for('profesor.dashboard'))
    return render_template("profesor/registrar_asistencia.html")

@profesor_bp.route('/modificar-asistencia', methods=['GET', 'POST'])
def modificar_asistencia():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()
    if request.method == 'POST':
        dni_alumno = request.form['dni_alumno']
        materia_id = request.form['materia_id']
        presente = request.form['presente'].lower() == 'true'
        resultado = UsuarioDAO.modificar_asistencia(session['usuario']['dni'], dni_alumno, materia_id, presente)
        flash(resultado.get('mensaje', 'Error'))
        return redirect(url_for('profesor.dashboard'))
    return render_template("profesor/modificar_asistencia.html")

@profesor_bp.route('/crear-examen', methods=['GET', 'POST'])
def crear_examen():
    if not validar_rol(['admin', 'profesor']):
        return redireccion_no_autorizado()

    cursos = PlanAcademicoDAO.obtener_cursos_con_anio()
    materias = []
    materia_horarios = {}
    horarios_disponibles = []

    if request.method == 'POST':
        curso_id = request.form.get('curso_id')
        materia_id = request.form.get('materia_id')
        fecha = request.form.get('fecha')
        hora = request.form.get('hora')
        titulo = request.form.get('titulo')
        dni = session['usuario']['dni']

        if fecha and hora and materia_id:
            resultado = ExamenDAO.crear_examen(curso_id, materia_id, fecha, hora, titulo, dni)
            flash(resultado.get('mensaje', 'Error al crear examen'))
            return redirect(url_for('profesor.dashboard'))
        elif curso_id:
            materias, materia_horarios = obtener_materias_y_horarios_por_curso(curso_id)

    return render_template(
        'admin/crear_examen.html',
        cursos=cursos,
        materias=materias,
        materia_horarios=materia_horarios
    )



def obtener_materias_y_horarios_por_curso(curso_id):
    datos = PlanAcademicoDAO.obtener_horarios_por_curso(curso_id)

    materias = []
    materia_horarios = []

    for mid, nombre, dia, h_ini, h_fin in datos:
        if (mid, nombre) not in materias:
            materias.append((mid, nombre))

        materia_horarios.append((mid, nombre, dia, h_ini, h_fin))

    return materias, materia_horarios


@profesor_bp.route("/ver-examenes")
def ver_examenes():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()

    profesor_id = session['usuario']['id']
    examenes = ExamenDAO.obtener_examenes_por_profesor(profesor_id)
    return render_template("profesor/ver_examenes_profesor.html", examenes=examenes)

@profesor_bp.route("/cronograma")
def cronograma_profesor():
    if not validar_rol('profesor'):
        return redireccion_no_autorizado()

    profesor_id = session['usuario']['id']
    curso_id = request.args.get("curso_id", type=int)

    cursos = PlanAcademicoDAO.obtener_cursos_por_profesor(profesor_id)

    if not cursos:
        curso_id = PlanAcademicoDAO.insertar_curso_con_materia_para_profesor(profesor_id)
        cursos = PlanAcademicoDAO.obtener_cursos_por_profesor(profesor_id)

    if not curso_id and cursos:
        curso_id = cursos[0].id

    materias, horarios = obtener_materias_y_horarios_por_curso(curso_id)

    examenes = ExamenDAO.obtener_examenes_por_profesor_y_curso(profesor_id, curso_id)

    dias_semana = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes']
    horas = [f"{h}:00" for h in range(8, 19)]
    cronograma = {dia: {hora: [] for hora in horas} for dia in dias_semana}

    for materia, dia, h_ini, h_fin in horarios:
        for h in range(int(h_ini.split(":")[0]), int(h_fin.split(":")[0])):
            hora_str = f"{h}:00"
            if hora_str in cronograma[dia]:
                cronograma[dia][hora_str].append({
                    "nombre": materia,
                    "tipo": "materia"
                })

    for ex in examenes:
        dia = ex['fecha'].strftime("%A").capitalize()
        hora = ex['hora_inicio'].strftime("%H:%M")
        if dia in cronograma and hora in cronograma[dia]:
            cronograma[dia][hora].append({
                "nombre": f"Ex: {ex['materia']}",
                "tipo": "examen"
            })

    return render_template("profesor/cronograma_profesor.html",
                           cursos=cursos,
                           curso_seleccionado=curso_id,
                           cronograma=cronograma,
                           dias_semana=dias_semana,
                           horas=horas)



